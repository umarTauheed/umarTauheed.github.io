
/*inserting th eimage into the div  */
var mainimg = document.createElement("img")
mainimg.src='https://cdn.sanity.io/images/czqk28jt/prod_bk_gb/df2429dc1d4cec108eec0ac4ed173ceacdb9ec6f-1450x500.jpg'
document.getElementById("main-image").appendChild(mainimg);

mainimg.style.width= "100%"; /* setting the width of th eimage in javascript */

/*inserting th eimage into the div  */
var plotimg = document.createElement("img")
plotimg.src='https://cdn.sanity.io/images/czqk28jt/prod_bk_gb/dfe44696b1cdbfaa0a4450e32b0b178b04430eb2-1184x600.jpg' 
document.getElementById("plot-twist").appendChild(plotimg);

plotimg.id = "plottwist";/* giving the image an id so it can be styled in css  */


var whopperimg = document.createElement("img")
whopperimg.src='https://cdn.sanity.io/images/czqk28jt/prod_bk_gb/c3d9508ce74de218b1fecb00dc11099e3ba10706-1000x507.jpg'
document.getElementById("whopper").appendChild(whopperimg);

whopperimg.id = "whoppers";/* giving the image an id so it can be styled in css  */


var offersimg = document.createElement("img")
offersimg.src='offers.png'
document.getElementById("greatoffers").appendChild(offersimg);

offersimg.id = "offers";/* giving the image an id so it can be styled in css  */


var freeimg = document.createElement("img")
freeimg.src='free.jpeg'
document.getElementById("free").appendChild(freeimg);

freeimg.id = "frees";/* giving the image an id so it can be styled in css  */

var phoneimg = document.createElement("img")
phoneimg.src='phone.png'
document.getElementById("phone").appendChild(phoneimg);

phoneimg.id = "phone";/* giving the image an id so it can be styled in css  */


var appstoreimg= document.createElement("img")
appstoreimg.src='https://developer.apple.com/app-store/marketing/guidelines/images/badge-example-preferred.png'
document.getElementById("apple").appendChild(appstoreimg);

appstoreimg.id = "apple";/* giving the image an id so it can be styled in css  */


var googleimg= document.createElement("img")
googleimg.src='https://lh3.googleusercontent.com/cjsqrWQKJQp9RFO7-hJ9AfpKzbUb_Y84vXfjlP0iRHBvladwAfXih984olktDhPnFqyZ0nu9A5jvFwOEQPXzv7hr3ce3QVsLN8kQ2Ao=s0'
document.getElementById("google").appendChild(googleimg);

googleimg.id = "google";/* giving the image an id so it can be styled in css  */


